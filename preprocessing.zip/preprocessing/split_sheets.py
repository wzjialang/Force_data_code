'''
This script reads the original data from 'Stars the limit original' dir seperates every excel sheet (attempt) to seperate csv files

'''


import os
import pandas as pd


def save_columns_to_csv(excel_file, surgeon_ID):
    # Read the Excel file into a dictionary of dataframes, one for each sheet
    dataframes = pd.read_excel(excel_file, sheet_name=None)

    # Iterate through each sheet and save the first and second columns to the combined dataframe
    for sheet_name, df in dataframes.items():
        if len(df.columns) != 2:
            print(f"Skipping sheet '{sheet_name}' as it doesn't have exactly two columns.")
            continue

        # Extract the first and second columns
        first_column_name = df.columns[0]
        second_column_name = df.columns[1]
        sheet_data = df[[first_column_name, second_column_name]]

        output_csv_file = os.path.join(os.getcwd(),'all_attempts')
        # Save the combined data to a CSV file
        sheet_data.to_csv(output_csv_file + '/' + surgeon_ID + '_' + sheet_name.replace('Sheet','attempt_') + '.csv', index=False)
        print("Data from all sheets has been saved to the CSV file:", output_csv_file)

# Replace the name of expert/novice
# Carefull! In the next line the first letter is capital like Expert and then space
# Whlile the surgeon ID there isn't any capital letter and there is an underscore 
excel_file_path = os.path.join(os.getcwd(),'Stars the limit original','Expert 7.xlsx')
surgeon_ID = 'expert_7'

save_columns_to_csv(excel_file_path,surgeon_ID)
print('complete')
