''' 
This script reads every csv attempt file from 'all_attempts' dir and replaces negative force values with zeros

'''


# Replacing negative values with zeros
import os
import pandas as pd

def replace_negative_with_zero(file_path):
    df = pd.read_csv(file_path)  # Read the CSV file into a DataFrame
    df.iloc[:, 1] = df.iloc[:, 1].apply(lambda x: max(0, x))  # Replace negative values with zero
    df.to_csv(file_path, index=False)  # Save the updated DataFrame back to the CSV file

def process_csv_files_in_folder(folder_path):
    for filename in os.listdir(folder_path):
        if filename.endswith('.csv'):  # Only process CSV files
            file_path = os.path.join(folder_path, filename)
            replace_negative_with_zero(file_path)

# Replace 'folder_path' with the path to your folder containing CSV files
folder_path = os.path.join(os.getcwd(),'all_attempts')
process_csv_files_in_folder(folder_path)

