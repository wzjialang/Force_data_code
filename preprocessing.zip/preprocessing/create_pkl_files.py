'''
This script every csv attempt file from 'all_attempts' dir and creates a pickle file depending the cross validation scheme you want

'''

import os
import random
import pickle


seed = 2
random.seed(seed)  # Python random module.

def data2list(folder_path):

    attempts_all = []
    attempt_list = os.listdir(folder_path)
    for attempt in attempt_list:
        attempts_all.append(attempt)

    return attempts_all


def split_list(lst, num_parts):
    avg_chunk_size = len(lst) // num_parts
    remainder = len(lst) % num_parts

    result = []
    start = 0

    for i in range(num_parts):
        end = start + avg_chunk_size + (1 if i < remainder else 0)
        result.append(lst[start:end])
        start = end

    return result



def create_pkl_file(data_dir,cross_val_scheme):

    data = data2list(data_dir)
    if cross_val_scheme == 'louo':
        fold_1, fold_2, fold_3, fold_4, fold_5, fold_6 = [],[],[],[],[],[]
        for attempt in data:
            if 'expert_1' in attempt or 'novice_1' in attempt:
                fold_1.append(attempt)
            elif 'expert_2' in attempt or 'expert_7' in attempt or 'novice_2' in attempt: # expert 7 is also added here
                fold_2.append(attempt)
            elif 'expert_3' in attempt or 'novice_3' in attempt:
                fold_3.append(attempt)                
            elif 'expert_4' in attempt or 'novice_4' in attempt:
                fold_4.append(attempt)    
            elif 'expert_5' in attempt or 'novice_5' in attempt:
                fold_5.append(attempt)
            elif 'expert_6' in attempt or 'novice_6' in attempt:
                fold_6.append(attempt)
        split_parts = [fold_1,fold_2,fold_3,fold_4,fold_5,fold_6]
        
    elif cross_val_scheme == 'random_split':
        # Shuffle the dataset
        random.shuffle(data)
        # Split the list into 6 parts
        split_parts = split_list(data, 6)


    # Sample data to be saved in the pickle file
    data_dict = {
        'fold_1': split_parts[0],
        'fold_2': split_parts[1],
        'fold_3': split_parts[2],
        'fold_4': split_parts[3],
        'fold_5': split_parts[4],
        'fold_6': split_parts[5],
    }
    # Replace 'file_path' with the path where you want to save the pickle file
    file_path = cross_val_scheme + '.pkl'
    # Create the pickle file
    with open(file_path, 'wb') as file:
        pickle.dump(data_dict, file)


# Create pickle file
data_dir = os.path.join(os.getcwd(),'all_attempts')
# Pick the cross validation scheme you want to create a pickle file for. Options: random_split, louo
cross_val_scheme = 'random_split'
create_pkl_file(data_dir=data_dir,cross_val_scheme=cross_val_scheme)


